# Sistema de confirmación para XV Años

## Incluye
- Registro de invitado principal.
- Hasta 3 acompañantes.
- Código único.
- QR individual.
- Verificación de entrada.
- Bloqueo de códigos reutilizados.
- Panel de invitados.
- Base de datos Supabase.

## Configuración
1. Crea un proyecto gratuito en Supabase.
2. Abre SQL Editor y ejecuta `schema.sql`.
3. Crea una cuenta en Render/Railway/Vercel u otro host para el backend Node.
4. Define estas variables de entorno en el backend:
   SUPABASE_URL=...
   SUPABASE_SERVICE_KEY=...
   ADMIN_KEY=una-clave-secreta
5. Cambia `API_URL` en `index.html` por la URL pública del backend.
6. Publica `index.html` en Netlify, Vercel o GitHub Pages.

IMPORTANTE: la SUPABASE_SERVICE_KEY y ADMIN_KEY son secretos. Nunca deben quedar dentro de index.html.
